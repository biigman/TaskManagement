# CPA Assignment

This project is designed as part of a CPA (Cloud Programming Assignment), integrating Firebase services with a Python backend and an HTML/JS frontend.


## 🚀 Features

- Firebase authentication integration
- Firestore database connectivity
- Firebase storage access
- Simple login/register system
- Frontend dashboard with Firebase interactivity

## 🧰 Backend Setup

1. Navigate to the `backend/` directory:
   ```bash
   cd backend
   ```

2. Create a virtual environment (optional but recommended):
   ```bash
   python -m venv venv
   source venv/bin/activate  
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Run the backend server:
   ```bash
   python main.py
   ```

## 🌐 Frontend

Open the `frontend/index.html` file in a browser. Make sure Firebase project settings (in `firebase-config.js`) match your Firebase console configuration.

## 🔐 Firebase Configuration

- Ensure you have added the Firebase project key JSON (`cpa-assignment-85189-bc2388c850f2.json`) to your environment or referenced it appropriately.
- Configure your Firebase project rules for Firestore and Authentication for local development.

## ✅ Requirements

- Python 3.12
- pip
- Firebase project credentials

## 📄 License

This project is for academic use only.
