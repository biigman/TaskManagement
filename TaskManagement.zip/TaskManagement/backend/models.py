# backend/models.py

from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime

class Task(BaseModel):
    title: str = Field(..., example="Finish report")
    description: Optional[str] = Field(None, example="Complete the 1500-word assignment report.")
    due_date: str = Field(..., example="2025-04-20")  # ISO date format
    assigned_to: Optional[str] = Field(None, example="user123")
    complete: bool = Field(default=False)

class Board(BaseModel):
    name: str = Field(..., example="Development Team")
    created_by: Optional[str] = Field(None, example="auth123")

class User(BaseModel):
    uid: str
    email: str
    display_name: Optional[str] = None
