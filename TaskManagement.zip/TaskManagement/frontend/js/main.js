// main.js — Enhanced logic for dashboard or board-specific tasks

const API_BASE = "http://localhost:8000"; // Adjust for deployment
let currentBoardId = null; // set from board.html URL param if needed

// Get token and verify login
function getToken() {
  const token = localStorage.getItem("idToken");
  if (!token) {
    alert("You are not logged in!");
    window.location.href = "index.html";
  }
  return token;
}

// Fetch and render tasks for a board (or globally if needed)
async function loadTasks(boardId = null) {
  const token = getToken();
  let url = `${API_BASE}/tasks`;
  if (boardId) url += `?board=${boardId}`;

  try {
    const res = await fetch(url, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });

    if (!res.ok) throw new Error("Failed to fetch tasks");
    const tasks = await res.json();
    const taskContainer = document.getElementById("task-list");

    taskContainer.innerHTML = ""; // Clear UI

    if (tasks.length === 0) {
      taskContainer.innerHTML = "<p class='text-gray-500'>No tasks yet for this board.</p>";
      return;
    }

    tasks.forEach(task => {
      const taskEl = document.createElement("div");
      taskEl.className = `card ${task.complete ? "task-complete" : "task-pending"} p-4 rounded shadow mb-2`;
      taskEl.innerHTML = `
        <h3 class="font-semibold text-lg">${task.title}</h3>
        <p class="text-sm text-gray-600">Due: ${task.due_date}</p>
        <p class="text-sm text-gray-600">Assigned to: ${task.assigned_to || "Unassigned"}</p>
        <p>Status: ${task.complete ? "✅ Complete" : "⏳ Incomplete"}</p>
      `;
      taskContainer.appendChild(taskEl);
    });

  } catch (err) {
    console.error("Task loading error:", err);
    alert("Error loading tasks.");
  }
}

// Handle new task creation for a specific board
async function handleTaskSubmit(event) {
  event.preventDefault();
  const token = getToken();

  const task = {
    title: document.getElementById("task-title").value.trim(),
    due_date: document.getElementById("due-date").value,
    assigned_to: document.getElementById("assigned-to").value || null,
    complete: false,
    board_id: currentBoardId || null
  };

  if (!task.title || !task.due_date) {
    alert("Title and due date are required.");
    return;
  }

  try {
    const res = await fetch(`${API_BASE}/task`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify(task)
    });

    if (!res.ok) throw new Error("Task creation failed");
    await loadTasks(currentBoardId);
    document.getElementById("task-form").reset();
  } catch (err) {
    console.error(err);
    alert("Failed to add task");
  }
}

// Utility to extract board ID from URL (used in board.html)
function getBoardIdFromURL() {
  const params = new URLSearchParams(window.location.search);
  return params.get("id");
}

// App bootstrap
document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("task-form");
  if (form) form.addEventListener("submit", handleTaskSubmit);

  // If board.html, get board ID
  if (document.getElementById("task-list")) {
    currentBoardId = getBoardIdFromURL();
    loadTasks(currentBoardId);
  }
});
