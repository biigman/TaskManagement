import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyDeK7dJoCT8DDDPXbW907guJicn4Q45OiQ",
  authDomain: "taskmanagement-bb759.firebaseapp.com",
  projectId: "taskmanagement-bb759",
  storageBucket: "taskmanagement-bb759.firebasestorage.app",
  messagingSenderId: "1069581634131",
  appId: "1:1069581634131:web:5b3ee5d1d188805d9a14a6",
  measurementId: "G-1C1BQZRC9R"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

export { auth };
