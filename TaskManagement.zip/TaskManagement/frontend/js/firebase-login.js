import { auth } from './firebase-config.js';
import {
  signInWithEmailAndPassword,
} from "https://www.gstatic.com/firebasejs/9.22.2/firebase-auth.js";

const loginForm = document.getElementById("login-form");
const statusText = document.getElementById("login-status");

loginForm.addEventListener("submit", (e) => {
  e.preventDefault();

  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value.trim();

  signInWithEmailAndPassword(auth, email, password)
    .then((userCredential) => {
      return userCredential.user.getIdToken();
    })
    .then((token) => {
      localStorage.setItem("authToken", token);
      statusText.textContent = "Login successful! Redirecting...";
      window.location.href = "index.html";
    })
    .catch((error) => {
      statusText.textContent = "Login failed: " + error.message;
    });
});
